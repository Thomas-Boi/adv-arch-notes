//
//  SceneDelegate.h
//  A01055477_Assignment1
//
//  Created by socas on 2021-02-17.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

