//
//  ViewController.h
//  glesbasics
//
//  Created by Borna Noureddin on 2020-01-14.
//  Copyright © 2020 BCIT. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Renderer.h" // ###

//@interface ViewController : UIViewController
@interface ViewController : GLKViewController // ###


@end
