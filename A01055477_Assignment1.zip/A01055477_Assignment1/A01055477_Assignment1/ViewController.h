//
//  ViewController.h
//  A01055477_Assignment1
//
//  Created by socas on 2021-02-17.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

